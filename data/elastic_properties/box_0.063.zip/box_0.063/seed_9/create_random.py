import numpy as np
from matplotlib import pyplot as plt
from scipy.optimize import fsolve

# My parameters

dmin = 0.0025
dmax = 0.0035
d0 = 0.003
seed_choice = 9
sizeX = 0.063
sizeY = 0.063
sizeZ = 0.063
distribution = "bi_size"

# Atom class ###################################################################

class Atom:
	def __init__(self, id, type, diameter, density, x, y, z):
		self.id = int(id)
		self.type = int(type)
		self.diameter = float(diameter)
		self.density = float(density)
		self.position = [float(x), float(y), float(z)]
	

# Create geometry ##############################################################

import sys
args = sys.argv

if (len(args) != 1 and len(args) != 6):
	print("Usage: python3 create_random.py [d0 dmax sizeX sizeY sizeZ]")
	quit()


#distribution = "lognormal" # gaussian or lognormal

if len(args) == 6:
	d0    = float(args[1])
	dmax  = float(args[2])
	sizeX = float(args[3])
	sizeY = float(args[4])
	sizeZ = float(args[5])
else:
#	d0    = 2e-9 # mean diameter
#	dmax  = 1.25 * d0
	sizeX = 0.063
	sizeY = 0.063
	sizeZ = 0.063

#dmin = 0.75 * d0
#drange = dmax - dmin
#sd = 0.2 * drange # std dev diameter

if distribution == "lognormal": # find mean and std dev for lognormal distribution (to have mode = d0)
	# sd_logn = fsolve(lambda sd_logn: (np.exp(sd_logn**2) - 1) * np.exp(2 * np.log(d0 - dmin) + sd_logn**2) - sd**2, 1)[0]
	sd_logn = np.sqrt(np.log(1 + sd**2 / (d0 - dmin)**2)) # first estimate
	for i in range(20): # iterate
		mu = d0 * np.exp(3 * sd_logn**2 / 2)
		mu_logn = np.log(mu**2 / np.sqrt(mu**2 + sd**2))
		sd_logn = np.sqrt(np.log(1 + sd**2 / mu**2))
	print("mean of lognormal distribution: {}".format(mu_logn))
	print("std. dev. of lognormal distribution: {}".format(sd_logn))
	# print(np.exp(mu_logn - sd_logn**2), np.sqrt((np.exp(sd_logn**2) - 1) * np.exp(2 * mu_logn + sd_logn**2))) # predicted mode and sd
        
fraction = 0.60 # volume occupied by the particles

# density will be set in relax*.in anyway
density = 1 # SiO2: 2200, Si: 2330
# density /= fraction
# print("modified density: {:0.0f}".format(density))
np.random.seed(seed_choice)

# box
xlo = -sizeX / 2
xhi =  sizeX / 2
ylo = -sizeY / 2
yhi =  sizeY / 2
zlo = -sizeZ / 2
zhi =  sizeZ / 2

# create atoms
atoms = []
Vtot = sizeX * sizeY * sizeZ
Vpart = 0 # volume occupied by particles
id = 0

while Vpart < fraction * Vtot:
    d = 0
    while d < dmin or d > dmax:
        if distribution == "gaussian":
            d = np.random.normal(d0, sd)
        if distribution == "lognormal":
            d = np.random.lognormal(mu_logn, sd_logn)
        if distribution == "bi_size":
            d = np.random.choice([dmin, dmax], 1, p=[0.5, 0.5])
        
    x = np.random.uniform(-sizeX / 2, sizeX / 2)
    y = np.random.uniform(-sizeY / 2, sizeY / 2)
    z = np.random.uniform(-sizeZ / 2, sizeZ / 2)
    id += 1
    atoms.append(Atom(id, 1, d, density, x, y, z))
    Vpart += 4 / 3 * np.pi * (d / 2) ** 3


# Statistics ###################################################################

n_atoms = len(atoms)
n_types = 1
print("Generated {} particles".format(n_atoms))

d_list = [atom.diameter for atom in atoms]
print("Diameters: min: {:1.2e}, mean: {:1.2e}, median: {:1.2e}, std. dev.: {:1.2e}\n".format(np.min(d_list), np.mean(d_list), np.median(d_list), np.std(d_list)))


# Export #######################################################################

file = open("box_0.063/seed_9/random.data", "w")

file.write("LAMMPS data file\n" +
           str(n_atoms) + " atoms\n" +
           str(n_types) + " atom types\n" +
		   str(xlo) + " " + str(xhi) + " xlo xhi\n" +
		   str(ylo) + " " + str(yhi) + " ylo yhi\n" +
		   str(zlo) + " " + str(zhi) + " zlo zhi\n"
		   )

file.write("\nAtoms # sphere\n\n")

for a in atoms:
	file.write(" ".join([str(a.id), str(a.type), str(a.diameter), str(a.density), str(a.position[0]), str(a.position[1]), str(a.position[2])]) + "\n")

file.write("\nVelocities\n\n")

for a in atoms:
	file.write(str(a.id) + " " + " ".join(["0.0"] * 6) + "\n")

file.close()


# Plot #########################################################################

# bins, _, _ = plt.hist(d_list, bins=25, range=(0, np.max(d_list)))
# plt.vlines(np.mean(d_list), 0, np.max(bins) * 1.1, linestyle="--")
# plt.xlim(left=0)
# plt.ylim([0, np.max(bins) * 1.1])
# plt.show()

