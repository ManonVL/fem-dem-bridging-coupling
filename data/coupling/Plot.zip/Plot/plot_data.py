import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from pylab import *
import scipy.interpolate
import numpy as np
import math 
import os
import csv

#from pgf_delete_family import pgf_delete_family
from matplotlib import rc

rc('font',**{'family':'serif','serif':['Computer Modern Roman']})
rc('font',**{'family':'serif'})
rc('text', usetex=True)

plt.rcParams.update({'figure.max_open_warning': 0})

def plot_data(path, nsteps, fe1_bot, fe1_top, fe2_bot, fe2_top, dem_bot, dem_top, dt, h, h2, err, I, y_value_fem):

    Y_fe1_all_steps = []
    Y_fe2_all_steps = []
    Y_dem_all_steps = []
 
    DY_fe1_all_steps = []
    DY_fe2_all_steps = []
    DY_dem_all_steps = []

    DX_fe1_all_steps = []
    DX_fe2_all_steps = []
    DX_dem_all_steps = []
    
    VY_fe1_all_steps = []
    VY_fe2_all_steps = []
    VY_dem_all_steps = []

    VX_fe1_all_steps = []
    VX_fe2_all_steps = []
    VX_dem_all_steps = []

    VZ_fe1_all_steps = []
    VZ_fe2_all_steps = []
    VZ_dem_all_steps = []

    FY_fe1_all_steps = []
    FY_fe2_all_steps = []
    FY_dem_all_steps = []

    FX_fe1_all_steps = []
    FX_fe2_all_steps = []
    FX_dem_all_steps = []

        
    DY_average_specific_section_through_time = []
    VY_average_specific_section_through_time = []    
    FY_average_specific_section_through_time = []

    DX_average_specific_section_through_time = []
    VX_average_specific_section_through_time = []    
    FX_average_specific_section_through_time = []

    DZ_average_specific_section_through_time = []
    VZ_average_specific_section_through_time = []    
    FZ_average_specific_section_through_time = []

    t = 0
    time = []
    
    for i in range(0, nsteps):
        ## data analysis
    
        t = t + i*dt
        time.append(t)

        if i < 10:
            open_fe1 = path + '/parafe1_000' + str(i) + '.csv'
            open_fe2 = path + '/parafe2_000' + str(i) + '.csv'
            open_dem = path + '/paramd_000' + str(i) + '.csv'

        if 10 <= i <100:
            open_fe1 = path + '/parafe1_00' + str(i) + '.csv'
            open_fe2 = path + '/parafe2_00' + str(i) + '.csv'
            open_dem = path + '/paramd_00' + str(i) + '.csv'

        if 100 <= i <1000:
            open_fe1 = path + '/parafe1_0' + str(i) + '.csv'
            open_fe2 = path + '/parafe2_0' + str(i) + '.csv'
            open_dem = path + '/paramd_0' + str(i) + '.csv'
            
        n = 0
        dy_plot = 0
        vy_plot = 0
        fy_plot = 0

        dx_plot = 0
        vx_plot = 0
        fx_plot = 0

        dz_plot = 0
        vz_plot = 0
        fz_plot = 0
        
        with open(open_fe2, 'r') as file:
            reader = csv.reader(file)
            for line in reader:
                if line[0] != 'displacement:0':
                    dx = line[0]
                    dy = line[1]
                    dz = line[2]
                    vx = line[3]
                    vy = line[4]
                    vz = line[5]
                    x = line[9]
                    y = line[10]
                    fx = line[6]
                    fy = line[7]
                    fz = line[8]
                    if float(y) == y_value_fem: 
                        dy_plot = dy_plot + float(dy)
                        vy_plot = vy_plot + float(vy)
                        fy_plot = fy_plot + float(fy)
                        dx_plot = dx_plot + float(dx)
                        vx_plot = vx_plot + float(vx)
                        fx_plot = fx_plot + float(fx)
                        dz_plot = dz_plot + float(dz)
                        vz_plot = vz_plot + float(vz)
                        fz_plot = fz_plot + float(fz)
                        n = n+1
        if n !=0:                
            DY_average_specific_section_through_time.append(float(dy_plot)/n)
            VY_average_specific_section_through_time.append(float(vy_plot)/n) 
            FY_average_specific_section_through_time.append(float(fy_plot)/n) 
            DX_average_specific_section_through_time.append(float(dx_plot)/n)
            VX_average_specific_section_through_time.append(float(vx_plot)/n) 
            FX_average_specific_section_through_time.append(float(fx_plot)/n)
            DZ_average_specific_section_through_time.append(float(dz_plot)/n)
            VZ_average_specific_section_through_time.append(float(vz_plot)/n) 
            FZ_average_specific_section_through_time.append(float(fz_plot)/n) 
            
        Y_fe1 = []
        DY_fe1 = []
        VY_fe1 = []
        FY_fe1 = []
        
        DX_fe1 = []
        VX_fe1 = []
        FX_fe1 = []
        VZ_fe1 = []
        
        with open(open_fe1, 'r') as file:
            reader = csv.reader(file)
            for line in reader:
                if line[0] != 'displacement:0':
                    dx = line[0]
                    dy = line[1]
                    vx = line[3]
                    vy = line[4]
                    vz = line[5]
                    y = line[10]
                    fx = line[6]
                    fy = line[7]          
                    Y_fe1.append(float(y))
                    DY_fe1.append(float(dy))
                    VY_fe1.append(float(vy))
                    VZ_fe1.append(float(vz))
                    FY_fe1.append(float(fy))
                    DX_fe1.append(float(dx))
                    VX_fe1.append(float(vx))
                    FX_fe1.append(float(fx))
 
        Y_fe2 = []
        DY_fe2 = []
        VY_fe2 = []
        FY_fe2 = []

        DX_fe2 = []
        VX_fe2 = []
        FX_fe2 = []
        VZ_fe2 = []
        
        with open(open_fe2, 'r') as file:
            reader = csv.reader(file)
            for line in reader:
                if line[0] != 'displacement:0':	
                    dx = line[0]
                    dy = line[1]
                    vx = line[3]
                    vy = line[4]
                    vz = line[5]
                    y = line[10]
                    fx = line[6]
                    fy = line[7]          
                    Y_fe2.append(float(y))
                    DY_fe2.append(float(dy))
                    VY_fe2.append(float(vy))
                    VZ_fe2.append(float(vz))
                    FY_fe2.append(float(fy))
                    DX_fe2.append(float(dx))
                    VX_fe2.append(float(vx))
                    FX_fe2.append(float(fx))  
                    
        Y_dem = []
        DY_dem = []
        VY_dem = []
        FY_dem = []

        DX_dem = []
        VX_dem = []
        FX_dem = []
        VZ_dem = []
        
        with open(open_dem, 'r') as file:
            reader = csv.reader(file)
            for line in reader:
                if line[0] != 'displacement:0':
                    truedispx = line[16]
                    truedispy = line[17]
                    vx = line[3]
                    vy = line[4]
                    vz = line[5]
                    y = line[20]
                    fx = line[6]
                    fy = line[7]
                    r = float(line[15])
                    Y_dem.append(float(y))
                    DY_dem.append(float(truedispy))           
                    VY_dem.append(float(vy))
                    FY_dem.append(float(fy))
                    DX_dem.append(float(truedispx))           
                    VX_dem.append(float(vx))
                    FX_dem.append(float(fx))
                    VZ_dem.append(float(vz))
                    
        Yref_fe1 = []
        yref_fe1 = fe1_bot
        
        while yref_fe1 < fe1_top:
            yref_fe1 =  yref_fe1 + h
            Yref_fe1.append(yref_fe1)
            
        Y_fe1_plot = []
        DY_fe1_plot = []
        VY_fe1_plot = []
        FY_fe1_plot = []

        DX_fe1_plot = []
        VX_fe1_plot = []
        FX_fe1_plot = []
        VZ_fe1_plot = []
        
        for r in range(len(Yref_fe1)):
            yref = Yref_fe1[r]
            n = 0
            y_plot = 0
            dy_plot = 0
            vy_plot = 0
            vz_plot = 0
            fy_plot = 0
            dx_plot = 0
            vx_plot = 0
            fx_plot = 0
            for j in range(len(Y_fe1)):
                if Y_fe1[j] > yref-err and Y_fe1[j] < yref+err :           
                    y_plot = y_plot + Y_fe1[j]
                    dy_plot = dy_plot + DY_fe1[j]
                    vy_plot = vy_plot + VY_fe1[j]
                    fy_plot = fy_plot + FY_fe1[j]
                    dx_plot = dx_plot + DX_fe1[j]
                    vx_plot = vx_plot + VX_fe1[j]
                    fx_plot = fx_plot + FX_fe1[j]
                    vz_plot = vz_plot + VZ_fe1[j]
                    n = n+1

            if n !=0 :             
                y_plot = y_plot/n
                dy_plot = dy_plot/n
                vy_plot = vy_plot/n
                fy_plot = fy_plot/n
                dx_plot = dx_plot/n
                vx_plot = vx_plot/n
                vz_plot = vz_plot/n
                fx_plot = fx_plot/n
                Y_fe1_plot.append(y_plot)
                DY_fe1_plot.append(dy_plot/I)
                VY_fe1_plot.append(vy_plot)
                FY_fe1_plot.append(fy_plot)
                DX_fe1_plot.append(dx_plot/I)
                VX_fe1_plot.append(vx_plot)
                FX_fe1_plot.append(fx_plot)
                VZ_fe1_plot.append(vz_plot)
               
        Yref_fe2 = []
        yref_fe2 = fe2_bot
        
        while yref_fe2 < fe2_top:
            yref_fe2 =  yref_fe2 + h
            Yref_fe2.append(yref_fe2)


        Y_fe2_plot = []
        DY_fe2_plot = []
        VY_fe2_plot = []
        FY_fe2_plot = []

        DX_fe2_plot = []
        VX_fe2_plot = []
        FX_fe2_plot = []
        VZ_fe2_plot = []
    
        for r in range(len(Yref_fe2)):
            yref = Yref_fe2[r]
            n = 0
            y_plot = 0
            dy_plot = 0
            vy_plot = 0
            fy_plot = 0
            dx_plot = 0
            vx_plot = 0
            vz_plot = 0
            fx_plot = 0
            for j in range(len(Y_fe2)):
                if Y_fe2[j] > yref-err and Y_fe2[j] < yref+err :           
                    y_plot = y_plot + Y_fe2[j]
                    dy_plot = dy_plot + DY_fe2[j]
                    vy_plot = vy_plot + VY_fe2[j]
                    vz_plot = vz_plot + VZ_fe2[j]
                    fy_plot = fy_plot + FY_fe2[j]
                    dx_plot = dx_plot + DX_fe2[j]
                    vx_plot = vx_plot + VX_fe2[j]
                    fx_plot = fx_plot + FX_fe2[j]
                    n = n+1

            if n !=0 :             
                y_plot = y_plot/n
                dy_plot = dy_plot/n
                vy_plot = vy_plot/n
                fy_plot = fy_plot/n
                dx_plot = dx_plot/n
                vx_plot = vx_plot/n
                vz_plot = vz_plot/n
                fx_plot = fx_plot/n
                Y_fe2_plot.append(y_plot)
                DY_fe2_plot.append(dy_plot/I)
                VY_fe2_plot.append(vy_plot)
                FY_fe2_plot.append(fy_plot)
                DX_fe2_plot.append(dx_plot/I)
                VX_fe2_plot.append(vx_plot)
                FX_fe2_plot.append(fx_plot)
                VZ_fe2_plot.append(vz_plot)
    
                
        Yref_dem = []
        yref_dem = dem_bot
        
        while yref_dem < dem_top:
            yref_dem =  yref_dem + h2
            Yref_dem.append(yref_dem)
            
        Y_dem_plot = []
        DY_dem_plot = []
        VY_dem_plot = []
        FY_dem_plot = []

        DX_dem_plot = []
        VX_dem_plot = []
        FX_dem_plot = []
        VZ_dem_plot = []
        
        for r in range(len(Yref_dem)):
            yref = Yref_dem[r]
            n = 0
            y_plot = 0
            dy_plot = 0
            vy_plot = 0
            fy_plot = 0
            dx_plot = 0
            vx_plot = 0
            vz_plot = 0
            fx_plot = 0
            for j in range(len(Y_dem)):
                if Y_dem[j] > yref-err and Y_dem[j] < yref+err :           
                    y_plot = y_plot + Y_dem[j]
                    dy_plot = dy_plot + DY_dem[j]
                    vy_plot = vy_plot + VY_dem[j]
                    fy_plot = fy_plot + FY_dem[j]
                    dx_plot = dx_plot + DX_dem[j]
                    vx_plot = vx_plot + VX_dem[j]
                    vz_plot = vz_plot + VZ_dem[j]
                    fx_plot = fx_plot + FX_dem[j]
                    n = n+1

            if n !=0 :             
                y_plot = y_plot/n
                dy_plot = dy_plot/n
                vy_plot = vy_plot/n
                fy_plot = fy_plot/n
                dx_plot = dx_plot/n
                vx_plot = vx_plot/n
                vz_plot = vz_plot/n
                fx_plot = fx_plot/n
                Y_dem_plot.append(y_plot)
                DY_dem_plot.append(dy_plot/I)
                VY_dem_plot.append(vy_plot)
                FY_dem_plot.append(fy_plot)
                DX_dem_plot.append(dx_plot/I)
                VX_dem_plot.append(vx_plot)
                VZ_dem_plot.append(vz_plot)

        # displacement diagram
        
        DY_fe1_all_steps.append(DY_fe1_plot)
        DY_fe2_all_steps.append(DY_fe2_plot)
        DY_dem_all_steps.append(DY_dem_plot)

        DX_fe1_all_steps.append(DX_fe1_plot)
        DX_fe2_all_steps.append(DX_fe2_plot)
        DX_dem_all_steps.append(DX_dem_plot)
        
        VY_fe1_all_steps.append(VY_fe1_plot)
        VY_fe2_all_steps.append(VY_fe2_plot)
        VY_dem_all_steps.append(VY_dem_plot)
        
        VX_fe1_all_steps.append(VX_fe1_plot)
        VX_fe2_all_steps.append(VX_fe2_plot)
        VX_dem_all_steps.append(VX_dem_plot)

        VZ_fe1_all_steps.append(VZ_fe1_plot)
        VZ_fe2_all_steps.append(VZ_fe2_plot)
        VZ_dem_all_steps.append(VZ_dem_plot)
        
        FY_fe1_all_steps.append(FY_fe1_plot)
        FY_fe2_all_steps.append(FY_fe2_plot)
        FY_dem_all_steps.append(FY_dem_plot)
        
        FX_fe1_all_steps.append(FX_fe1_plot)
        FX_fe2_all_steps.append(FX_fe2_plot)
        FX_dem_all_steps.append(FX_dem_plot)
        
        Y_fe1_all_steps.append(Y_fe1_plot)
        Y_fe2_all_steps.append(Y_fe2_plot)
        Y_dem_all_steps.append(Y_dem_plot)
               
    data = [Y_fe1_all_steps,
            Y_fe2_all_steps,
            Y_dem_all_steps,
            DY_fe1_all_steps,
            DY_fe2_all_steps,
            DY_dem_all_steps,
            time,
            VY_fe1_all_steps,
            VY_fe2_all_steps,
            VY_dem_all_steps,
            FY_fe1_all_steps,
            FY_fe2_all_steps,
            FY_dem_all_steps,
            DX_fe1_all_steps,
            DX_fe2_all_steps,
            DX_dem_all_steps,
            VX_fe1_all_steps,
            VX_fe2_all_steps,
            VX_dem_all_steps,
            FX_fe1_all_steps,
            FX_fe2_all_steps,
            FX_dem_all_steps,
            DY_average_specific_section_through_time,
            VY_average_specific_section_through_time,
            FY_average_specific_section_through_time,
            DX_average_specific_section_through_time,
            VX_average_specific_section_through_time,
            FX_average_specific_section_through_time,
            DZ_average_specific_section_through_time,
            VZ_average_specific_section_through_time,
            FZ_average_specific_section_through_time,
            VZ_fe1_all_steps,
            VZ_fe2_all_steps,
            VZ_dem_all_steps]

    with open(path + '/data.csv', 'w', newline='') as f:
        writer = csv.writer(f)	
        # write multiple rows
        writer.writerows(data)
    
    return("Done")    
   
  
