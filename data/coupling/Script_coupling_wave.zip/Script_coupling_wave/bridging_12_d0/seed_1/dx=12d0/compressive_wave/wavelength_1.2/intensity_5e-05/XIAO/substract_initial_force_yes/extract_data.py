import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from pylab import *
import scipy.interpolate
import numpy as np
import math 
import glob, os

import csv
import sys

sys.path.insert(1, "../../../../../../../../.." + '/DEM')
import dem_dimensions

sys.path.insert(1, "../../../../../../../../.." + '/Plot')

from pvtu_to_csv import pvtu_to_csv
from plot_data import plot_data

## Transform pvtu to csv
    
pvtu_input_directory = "./"
csv_output_directory = "./"
number_of_csv_limit = 130
pvtu_to_csv(pvtu_input_directory, csv_output_directory, number_of_csv_limit)

## Extract data

DEMLX, DEMLY, DEMLZ = dem_dimensions.dem_dimensions("../../../../../..", "/confined_5.0_MPa_duplicated_position.data")
DEMLX = round(DEMLX,6)
DEMLY = round(DEMLY,6)
DEMLZ = round(DEMLZ,6)
FEMLX = DEMLX
FEMLZ = DEMLZ
dem_bot = -DEMLY/2
dem_top = DEMLY/2

fe1_bot = -1.2959999999999998*2 - 0.06/2
fe1_top = -0.06/2
fe2_bot = 0.06/2
fe2_top = 1.2959999999999998*2 + 0.06/2

y_value_fem = around(0.136521, 5)


plot_data("./", number_of_csv_limit, fe1_bot, fe1_top, fe2_bot, fe2_top, dem_bot, dem_top, 1e-08, 0.002, 0.00125, 0.001, 1, y_value_fem)
