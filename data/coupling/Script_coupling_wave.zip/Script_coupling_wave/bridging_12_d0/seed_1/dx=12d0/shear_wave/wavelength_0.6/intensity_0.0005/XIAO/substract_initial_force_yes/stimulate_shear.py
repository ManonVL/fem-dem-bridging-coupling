
import numpy as np
import math

def compute(input=None, constants=None, **kwargs):

    pos0 = input
    disp = np.zeros(pos0.shape)
    L = constants["WaveLength"]
    I = constants["WaveIntensity"]
    A = constants["A"]
    dt = constants["ReadTimestep"]
    step = kwargs["step"]

    t = step * dt
    
    E = 977000000
    rho = 1643
    nu = 0.255
    cp = math.sqrt(E/rho)
    cs = cp/(math.sqrt((2*(1-nu))/(1-2*nu)))
    T = L/cs
    t0 = T/2
    
    for i in range(len(pos0)):
            disp[:, 0] = I*math.exp(-1/2*(2*np.pi*(t-t0)/T)**2)      
    return disp


if __name__ == "__main__":
    pass
    
    
    
